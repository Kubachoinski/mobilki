package com.example.infczw

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.SeekBar
import com.example.infczw.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(LayoutInflater.from(this))
        var lista = arrayListOf<String>("Dzień Dobry","Good Morning","Buenas Dias")
        var a = 0

        setContentView(binding.root)
        with(binding){
            zmienrozmiar.text = "Dzień Dobry"
            sigmabar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
                override fun onStartTrackingTouch(seekBar: SeekBar?) {

                }

                override fun onStopTrackingTouch(seekBar: SeekBar?) {

                }

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    rozmiar.text = "Rozmiar: " + sigmabar.progress.toString()
                    zmienrozmiar.textSize = sigmabar.progress.toFloat()

                }
            })
            button.setOnClickListener {
                if (a>2){
                    a = 0
                }
                zmienrozmiar.text = lista[a]
                a +=1
            }


        }

    }
}