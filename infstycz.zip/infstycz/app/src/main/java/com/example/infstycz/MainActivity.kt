package com.example.infstycz

import android.R
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import com.example.infstycz.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(LayoutInflater.from(this))
        var lista = mutableListOf("Zakupy: Chleb, Ser, Masło","Do Zrobienia: obiad, umyć podłogi","weekend: kino, spacer z psem")
        setContentView(binding.root)
        var arrayAdapter: ArrayAdapter<String>
        arrayAdapter = ArrayAdapter(this, R.layout.simple_list_item_1,lista)
        with(binding){
            todolist.adapter = arrayAdapter
            button.setOnClickListener {
                lista.add(editTextText.text.toString())
                arrayAdapter.notifyDataSetChanged()


            }

        }
    }
}